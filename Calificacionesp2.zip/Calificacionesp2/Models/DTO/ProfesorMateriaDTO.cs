﻿namespace Backend.API.Models.DTOs
{
    public class ProfesorMateriaDTO
    {
        public int IdProfesor { get; set; }
        public int IdMateria { get; set; }
    }
}
