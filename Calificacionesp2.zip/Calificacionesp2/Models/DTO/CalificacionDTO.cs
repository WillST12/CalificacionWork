﻿namespace Backend.API.Models.DTOs
{
    public class CalificacionDTO
    {
        public int IdClaseAlumno { get; set; }
        public decimal Nota { get; set; } 
    }
}
