﻿namespace Backend.API.Models.DTOs
{
    public class MateriaDTO
    {
        public string Nombre { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
    }
}
