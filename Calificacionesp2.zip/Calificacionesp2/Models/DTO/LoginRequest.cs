﻿namespace Backend.API.Models.DTOs
{
    public class LoginRequest
    {
        public string NombreUsuario { get; set; }
        public string Contrasena { get; set; }
    }
}
